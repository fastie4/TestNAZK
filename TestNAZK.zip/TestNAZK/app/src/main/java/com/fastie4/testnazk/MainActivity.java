package com.fastie4.testnazk;

import android.os.Parcelable;
import android.support.constraint.Group;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.Menu;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.fastie4.testnazk.adapter.RecyclerViewAdapter;
import com.fastie4.testnazk.mvp.MainActivityContract;
import com.fastie4.testnazk.mvp.PresenterImpl;
import com.fastie4.testnazk.pojo.Item;
import com.jakewharton.rxbinding2.support.v7.widget.RxSearchView;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import dagger.android.AndroidInjection;

public class MainActivity extends AppCompatActivity implements MainActivityContract.View {
    static final String LIST_DATA = "list_data";
    static final String PROGRESS = "progress";
    static final String NO_CONNECTION = "no_connection";
    static final String NO_RESULTS = "no_results";

    @BindView(R.id.progress)
    ProgressBar mProgress;
    @BindView(R.id.recycler)
    RecyclerView recyclerView;
    @BindView(R.id.no_connection)
    Group mNoConnection;
    @BindView(R.id.no_results)
    TextView mNoResults;

    @Inject
    PresenterImpl presenter;

    @Inject
    RecyclerViewAdapter adapter;
    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AndroidInjection.inject(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        mProgress.setVisibility(View.GONE);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        recyclerView.setAdapter(adapter);

        if (savedInstanceState != null) {
            List<Item> data = savedInstanceState.getParcelableArrayList(LIST_DATA);
            if (data != null) {
                adapter.setItems(data);
            }
            mProgress.setVisibility(savedInstanceState.getInt(PROGRESS));
            mNoConnection.setVisibility(savedInstanceState.getInt(NO_CONNECTION));
            mNoResults.setVisibility(savedInstanceState.getInt(NO_RESULTS));
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        List<Item> data = adapter.getItems();
        if (data != null) {
            outState.putParcelableArrayList(LIST_DATA, (ArrayList<? extends Parcelable>) data);
        }
        outState.putInt(PROGRESS, mProgress.getVisibility());
        outState.putInt(NO_CONNECTION, mNoConnection.getVisibility());
        outState.putInt(NO_RESULTS, mNoResults.getVisibility());
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        presenter.detach();
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        searchView = (SearchView) menu.findItem(R.id.search).getActionView();
        presenter.observeSearch(RxSearchView.queryTextChangeEvents(searchView));
        return true;
    }

    @Override
    public void showProgress() {
        searchView.clearFocus();
        mProgress.setVisibility(View.VISIBLE);

        mNoResults.setVisibility(View.GONE);
        mNoConnection.setVisibility(View.GONE);
        recyclerView.setVisibility(View.GONE);
    }

    @Override
    public void hideProgress() {
        mProgress.setVisibility(View.GONE);
    }

    @Override
    public void noConnection() {
        mNoConnection.setVisibility(View.VISIBLE);
    }

    @Override
    public void showData(List<Item> data) {
        adapter.setItems(data);
        if (data == null || data.isEmpty()) {
            mNoResults.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
        }
    }
}
