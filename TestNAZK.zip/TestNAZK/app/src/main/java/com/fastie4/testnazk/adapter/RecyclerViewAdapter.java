package com.fastie4.testnazk.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.fastie4.testnazk.R;
import com.fastie4.testnazk.pojo.Item;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private List<Item> items;

    public RecyclerViewAdapter() {
        items = new ArrayList<>();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater
                .from(viewGroup.getContext())
                .inflate(R.layout.recycler_view_row, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        Item item = items.get(i);
        viewHolder.mFirstName.setText(item.firstname);
        viewHolder.mLastName.setText(item.lastname);
        viewHolder.mPlaceOfWork.setText(item.placeOfWork);
        if (item.position == null /*|| item.position.isEmpty() || item.position.equals("ні")*/) {
            viewHolder.mPosition.setVisibility(View.GONE);
        } else {
            viewHolder.mPosition.setVisibility(View.VISIBLE);
            viewHolder.mPosition.setText(item.position);
        }
    }

    @Override
    public int getItemCount() {
        if (items != null) {
            return items.size();
        } else return 0;
    }

    public void setItems(List<Item> items) {
        this.items = items;
        notifyDataSetChanged();
    }

    public List<Item> getItems() {
        return items;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.first_name) TextView mFirstName;
        @BindView(R.id.last_name) TextView mLastName;
        @BindView(R.id.position) TextView mPosition;
        @BindView(R.id.place_of_work) TextView mPlaceOfWork;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
