package com.fastie4.testnazk.di.component;

import android.app.Application;
import android.content.Context;

import com.fastie4.testnazk.App;
import com.fastie4.testnazk.di.module.AdapterModule;
import com.fastie4.testnazk.di.module.ContextModule;
import com.fastie4.testnazk.di.module.MainActivityModule;
import com.fastie4.testnazk.di.module.MainActivityMvpModule;
import com.fastie4.testnazk.di.module.RetrofitModule;
import com.fastie4.testnazk.di.qualifier.ApplicationContext;
import com.fastie4.testnazk.retrofit.APIInterface;

import javax.inject.Singleton;

import dagger.BindsInstance;
import dagger.Component;
import dagger.android.AndroidInjectionModule;

@Singleton
@Component(modules = {AndroidInjectionModule.class, ContextModule.class, RetrofitModule.class, MainActivityModule.class})
public interface ApplicationComponent {
    APIInterface getApi();

    @ApplicationContext
    Context getContext();

    @Component.Builder
    interface Builder {
        @BindsInstance
        Builder application(Application app);
        ApplicationComponent build();
    }

    void inject(App app);
}
