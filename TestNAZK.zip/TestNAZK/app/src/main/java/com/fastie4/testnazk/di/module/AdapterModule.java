package com.fastie4.testnazk.di.module;

import android.support.v7.widget.RecyclerView;

import com.fastie4.testnazk.adapter.RecyclerViewAdapter;
import com.fastie4.testnazk.di.scopes.ActivityScope;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
public class AdapterModule {
    @Provides
    @ActivityScope
    public RecyclerViewAdapter getList() {
        return new RecyclerViewAdapter();
    }
}
