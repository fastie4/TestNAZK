package com.fastie4.testnazk.di.module;

import android.app.Application;
import android.content.Context;

import com.fastie4.testnazk.di.qualifier.ApplicationContext;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
public class ContextModule {
    @Provides
    @Singleton
    @ApplicationContext
    public Context provideContext(Application app) {
        return app;
    }
}
