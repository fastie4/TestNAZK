package com.fastie4.testnazk.di.module;

import com.fastie4.testnazk.MainActivity;
import com.fastie4.testnazk.di.scopes.ActivityScope;
import com.fastie4.testnazk.mvp.MainActivityContract;

import dagger.Module;
import dagger.Provides;

@Module
public class MainActivityMvpModule {
    @Provides
    @ActivityScope
    MainActivityContract.View provideView(MainActivity a) {
        return a;
    }
}