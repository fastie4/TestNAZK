package com.fastie4.testnazk.di.qualifier;

import javax.inject.Qualifier;

@Qualifier
public @interface ApplicationContext {
}
