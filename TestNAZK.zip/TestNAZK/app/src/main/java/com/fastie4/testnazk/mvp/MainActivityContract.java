package com.fastie4.testnazk.mvp;

import android.support.v7.widget.SearchView;

import com.fastie4.testnazk.pojo.Item;
import com.jakewharton.rxbinding2.support.v7.widget.SearchViewQueryTextEvent;

import java.util.List;

import io.reactivex.Observable;

public interface MainActivityContract {
    interface View {
        void showProgress();
        void hideProgress();
        void noConnection();
        void showData(List<Item> data);
    }

    interface Presenter {
        void observeSearch(Observable<SearchViewQueryTextEvent> queryText);
        void detach();
    }
}
