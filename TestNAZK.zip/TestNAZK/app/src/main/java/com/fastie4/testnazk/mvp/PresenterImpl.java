package com.fastie4.testnazk.mvp;

import android.util.Log;

import com.fastie4.testnazk.pojo.Declaration;
import com.fastie4.testnazk.retrofit.APIInterface;
import com.fastie4.testnazk.rx.RetryWhenHTTP429WithDelay;
import com.jakewharton.rxbinding2.support.v7.widget.SearchViewQueryTextEvent;

import java.net.SocketTimeoutException;

import javax.inject.Inject;

import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

public class PresenterImpl implements MainActivityContract.Presenter {
    private APIInterface mApiInterface;
    private MainActivityContract.View mView;

    CompositeDisposable disposable;

    @Inject
    public PresenterImpl(APIInterface apiInterface, MainActivityContract.View view) {
        Log.d("test", "New presenter");
        mApiInterface = apiInterface;
        mView = view;
    }

    @Override
    public void observeSearch(Observable<SearchViewQueryTextEvent> queryText) {
        queryText.filter(SearchViewQueryTextEvent::isSubmitted)
                .observeOn(AndroidSchedulers.mainThread())
                .map(searchViewQueryTextEvent -> {
                    mView.showProgress();
                    return searchViewQueryTextEvent;
                })
                .observeOn(Schedulers.io())
                .switchMap(searchViewQueryTextEvent ->
                    mApiInterface.getDeclarations(searchViewQueryTextEvent.queryText().toString())
                            .retryWhen(new RetryWhenHTTP429WithDelay(5, 3000))
                            .observeOn(AndroidSchedulers.mainThread())
                            .onErrorResumeNext(throwable -> {
                                handleHttpError(throwable);
                                return Observable.empty();
                            }))
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<Declaration>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                    }

                    @Override
                    public void onNext(Declaration declaration) {
                        mView.hideProgress();
                        mView.showData(declaration.items);
                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onComplete() {
                    }
                });
    }

    @Override
    public void detach() {
        mView = null;
    }

    private void handleHttpError(Throwable throwable) {
        mView.hideProgress();
        mView.noConnection();
    }
}
